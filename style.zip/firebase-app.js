// Firebase App
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";

export const firebaseConfig = {
  apiKey: "AIzaSyDVnndWYr_Q103e6NS6gKGf5GTkrywrvTg",
  authDomain: "money-note-6577f.firebaseapp.com",
  projectId: "money-note-6577f",
  storageBucket: "money-note-6577f.firebasestorage.app",
  messagingSenderId: "796636671958",
  appId: "1:796636671958:web:1d7cb29bcbed3cc2a33e77"
};

export const app = initializeApp(firebaseConfig);
